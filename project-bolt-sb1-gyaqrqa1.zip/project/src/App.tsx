import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Footer } from './components/Footer';
import { ContactFormModal } from './components/ContactFormModal';
import { NewsletterModal } from './components/NewsletterModal';
import { FormProvider, useFormContext } from './context/FormContext';
import { useFormTriggers } from './hooks/useFormTriggers';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Services } from './pages/Services';
import { Contact } from './pages/Contact';
import { CaseStudies } from './pages/CaseStudies';
import { FAQs } from './pages/FAQs';
import { Resources } from './pages/Resources';

function AppContent() {
  const { showContactForm, showNewsletterForm, downloadUrl, closeContactForm, closeNewsletterForm } = useFormContext();
  useFormTriggers();

  return (
    <div className="min-h-screen bg-[#f5f1ed]">
      <Navigation />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/case-studies" element={<CaseStudies />} />
        <Route path="/faqs" element={<FAQs />} />
        <Route path="/resources" element={<Resources />} />
      </Routes>
      <Footer />
      <ContactFormModal isOpen={showContactForm} onClose={closeContactForm} />
      <NewsletterModal isOpen={showNewsletterForm} onClose={closeNewsletterForm} downloadUrl={downloadUrl} />
    </div>
  );
}

function App() {
  return (
    <Router>
      <FormProvider>
        <AppContent />
      </FormProvider>
    </Router>
  );
}

export default App;
