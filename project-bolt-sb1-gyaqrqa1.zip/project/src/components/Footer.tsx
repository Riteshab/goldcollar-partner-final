import logoImage from '../assets/GC_Logo_Assets.png';

export function Footer() {
  return (
    <footer className="bg-[#3a3a3a] text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <img
                src={logoImage}
                alt="Gold Collar Partners"
                className="h-10 w-10 object-contain"
              />
              <span className="text-lg font-semibold" style={{ fontFamily: 'Brown Sugar, cursive' }}>
                <span className="text-white">Gold Collar</span>
                <span className="text-[#d4a855]"> Partners</span>
              </span>
            </div>
            <p className="text-white/70 text-sm">
              Transforming property investment dreams into reality across Australia.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-white/70 text-sm">
              <li>Buyers Agent</li>
              <li>Property Developer</li>
              <li>Luxury Club</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-white/70 text-sm">
              <li>About Us</li>
              <li>Case Studies</li>
              <li>FAQs</li>
              <li>Contact</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <p className="text-white/70 text-sm">
              Email: info@goldcollerpartners.com.au<br />
              Phone: 1300 GOLD COLLER<br />
              Sydney | Melbourne | Brisbane
            </p>
          </div>
        </div>
        <div className="border-t border-white/10 mt-8 pt-8 text-center text-white/60 text-sm">
          <p>&copy; 2025 Gold Collar Partners. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
