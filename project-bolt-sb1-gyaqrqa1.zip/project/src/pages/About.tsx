import { useFormContext } from '../context/FormContext';

export function About() {
  const { openContactForm } = useFormContext();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">
          About <span className="text-[#8b7355]">Gold Collar Partners</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Australia's premier real estate solution provider, dedicated to transforming property investment dreams into reality.
        </p>
      </div>

      <section className="mb-16">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] rounded-3xl p-8 text-white shadow-2xl">
            <div className="text-xs uppercase tracking-widest opacity-90 mb-6 font-semibold">
              Our Credibility & Experience
            </div>
            <div className="space-y-6">
              <div>
                <div className="text-6xl font-bold mb-2">250+</div>
                <div className="text-lg font-medium opacity-95">Properties Delivered</div>
                <p className="text-sm opacity-80 mt-2">Across premium Australian locations</p>
              </div>
              <div className="border-t border-white/20 pt-6">
                <div className="text-5xl font-bold mb-2">$800M+</div>
                <div className="text-lg font-medium opacity-95">Total Investments</div>
                <p className="text-sm opacity-80 mt-2">Managed successfully</p>
              </div>
              <div className="border-t border-white/20 pt-6">
                <div className="text-5xl font-bold mb-2">15+</div>
                <div className="text-lg font-medium opacity-95">Years of Experience</div>
                <p className="text-sm opacity-80 mt-2">In premium real estate</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 bg-white rounded-3xl p-8 shadow-xl border border-gray-100">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
                  <p className="text-gray-700 leading-relaxed">
                    At Gold Collar Partners, we understand the challenges of creating exceptional property portfolios. We've designed our services around what investors truly need - transparency, expertise, and results.
                  </p>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Approach</h2>
                  <p className="text-gray-700 leading-relaxed">
                    We combine deep market insights with personalized service, providing transparent guidance from initial consultation to final acquisition and beyond.
                  </p>
                </div>
              </div>
              <div className="space-y-6">
                <div className="relative h-64 rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800"
                    alt="Professional team meeting"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="bg-[#f5f1ed] rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Why Choose Us?</h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>Exclusive access to off-market properties</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>End-to-end investment support</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>Proven track record of success</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>Personalized investment strategies</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-16">
        <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
          Our <span className="text-[#8b7355]">Values</span>
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-3">Transparency</h3>
            <p className="text-gray-700">
              We believe in complete honesty and clarity in all our dealings. Every step of your investment journey is transparent and well-communicated.
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-3">Excellence</h3>
            <p className="text-gray-700">
              We maintain the highest standards in property selection, due diligence, and client service. Excellence is not just a goal, it's our standard.
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-3">Trust</h3>
            <p className="text-gray-700">
              Building long-term relationships based on trust and proven results is at the heart of everything we do. Your success is our success.
            </p>
          </div>
        </div>
      </section>

      <section className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900">
            Why <span className="text-[#8b7355]">Choose</span> Gold Collar Partners
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-[#f5f1ed] rounded-2xl p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">End-to-End Solutions</h3>
            <p className="text-gray-700 mb-6">
              We manage every aspect of your property investment journey. From market research and sourcing to acquisition and ongoing management, we provide complete peace of mind.
            </p>
            <div className="flex justify-center">
              <svg width="100" height="60" viewBox="0 0 100 60" className="text-[#8b7355]">
                <path d="M10 30 Q 25 15, 40 30 T 70 30 T 90 30" stroke="currentColor" strokeWidth="3" fill="none" />
                <path d="M10 40 Q 25 25, 40 40 T 70 40 T 90 40" stroke="currentColor" strokeWidth="3" fill="none" />
              </svg>
            </div>
          </div>

          <div className="bg-[#8b7355] rounded-2xl p-8 text-white">
            <h3 className="text-xl font-bold mb-4">Personalized Service</h3>
            <p className="mb-6 text-white/90">
              We don't believe in providing a generic service. Our dedicated team works closely with you to understand your unique goals and deliver tailored solutions that maximize your returns.
            </p>
          </div>

          <div className="relative h-80 rounded-2xl overflow-hidden shadow-xl">
            <img
              src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Modern conference room"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent flex items-end">
              <div className="p-8 text-white">
                <h3 className="text-2xl font-bold mb-2">Superior Quality</h3>
                <p className="text-white/90">
                  Our partnerships with elite suppliers grant us access to premium properties and exclusive opportunities unavailable to the general market.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#3a3a3a] rounded-2xl p-8 text-white">
            <h3 className="text-xl font-bold mb-4">Proven Track Record</h3>
            <p className="mb-6 text-white/90">
              We specialize in sourcing premium-grade boutique properties that are both on and off-market, ensuring you gain access to the finest selection and achieve optimal returns on your investment.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] rounded-3xl p-12 text-white text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to Start Your Investment Journey?</h2>
        <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
          Join hundreds of satisfied investors who have achieved their property goals with Gold Collar Partners.
        </p>
        <button onClick={openContactForm} className="bg-white text-[#8b7355] px-8 py-3 rounded-lg font-semibold hover:bg-[#f5f1ed] transition shadow-xl">
          Schedule a Consultation
        </button>
      </section>
    </div>
  );
}
