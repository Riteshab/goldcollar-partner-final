import { Play, BookOpen, FileText, Calculator } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useFormContext } from '../context/FormContext';

export function Home() {
  const { openContactForm, openNewsletterForm } = useFormContext();

  return (
    <>
      <section className="relative" style={{ marginTop: '-32px' }}>
        <div className="relative h-[580px] bg-gradient-to-br from-[#8b7355] to-[#6d5a42] overflow-hidden rounded-[32px] max-w-[95%] lg:max-w-[90%] mx-auto shadow-2xl">
          <div className="absolute inset-0 opacity-50">
            <video
              autoPlay
              loop
              muted
              playsInline
              preload="auto"
              className="w-full h-full object-cover"
              src="https://tmpfiles.org/dl/3892154/invideo-ai-10805secondsofpureluxuryrealestate2025-10-12.mp4"
            />
          </div>

          <div className="h-[80px]"></div>

          <div className="relative flex items-center justify-between px-8 sm:px-12 lg:px-16 h-full">
            <div className="max-w-2xl">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
                Transforming Dreams<br />
                <span className="text-[#f5f1ed]">Into Reality</span>
              </h1>
              <p className="text-base md:text-lg text-white/90 mb-8 leading-relaxed max-w-xl">
                Gold Collar Partners delivers the complete process of investing in exclusive boutique-designed luxury properties across premium locations in Australia.
              </p>
              <div className="lg:hidden">
                <button onClick={openContactForm} className="bg-white text-[#8b7355] px-7 py-2.5 rounded-md font-medium hover:bg-[#f5f1ed] transition shadow-lg text-sm">
                  Start Your Investment Journey
                </button>
              </div>
            </div>
            <div className="hidden lg:block">
              <button onClick={openContactForm} className="bg-white text-[#8b7355] px-7 py-3 rounded-md font-semibold hover:bg-[#f5f1ed] transition shadow-xl text-sm">
                Start Your Investment Journey
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div className="relative bg-gradient-to-br from-[#8b7355] to-[#6d5a42] rounded-2xl overflow-hidden shadow-xl h-[450px] group cursor-pointer">
            <img
              src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1920"
              alt="Business presentation"
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-white rounded-full p-6 shadow-2xl group-hover:scale-110 transition-transform">
                <Play className="h-12 w-12 text-[#8b7355]" fill="currentColor" />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Discover Our <span className="text-[#8b7355]">Approach</span>
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                At Gold Collar Partners, we pride ourselves on delivering comprehensive real estate solutions that transform investment dreams into tangible reality. Our approach combines deep market expertise with personalized service to ensure every client achieves their property investment goals.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                With over 250 successful property transactions and more than $800 million in managed investments, we've established ourselves as Australia's trusted partner for premium real estate acquisitions and developments.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Whether you're a first-time investor or a seasoned developer, our team provides tailored strategies, exclusive market access, and end-to-end support throughout your entire property journey.
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <div className="bg-[#8b7355] text-white px-6 py-3 rounded-lg">
                <div className="text-2xl font-bold">250+</div>
                <div className="text-sm opacity-90">Properties</div>
              </div>
              <div className="bg-[#8b7355] text-white px-6 py-3 rounded-lg">
                <div className="text-2xl font-bold">$800M+</div>
                <div className="text-sm opacity-90">Investments</div>
              </div>
              <div className="bg-[#8b7355] text-white px-6 py-3 rounded-lg">
                <div className="text-2xl font-bold">15+</div>
                <div className="text-sm opacity-90">Years Experience</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Our <span className="text-[#8b7355]">Divisions</span>
          </h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Comprehensive real estate solutions tailored to your investment goals and lifestyle aspirations.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-start">
          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="text-6xl font-bold text-[#8b7355]/10 mb-3">1</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Buyers <span className="text-[#8b7355]">Agent</span>
              </h3>
              <p className="text-gray-700 leading-relaxed">
                Our commitment to your success extends beyond the final acquisition. We conduct thorough market analysis to ensure your satisfaction, provide comprehensive due diligence, and offer ongoing support for warranty claims, maintenance, and seller negotiations.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="text-6xl font-bold text-[#8b7355]/10 mb-3">2</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Property <span className="text-[#8b7355]">Developer</span>
              </h3>
              <p className="text-gray-700 leading-relaxed">
                We specialize in creating bespoke developments that maximize value and deliver exceptional returns. Our end-to-end development service includes site acquisition, design consultation, planning approvals, and project management to bring your vision to life.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="text-6xl font-bold text-[#8b7355]/10 mb-3">3</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Luxury <span className="text-[#8b7355]">Club</span>
              </h3>
              <p className="text-gray-700 leading-relaxed">
                Exclusive membership providing access to off-market opportunities, private viewings, and premium investment insights. Our luxury club members receive priority access to high-yield properties and bespoke investment strategies tailored to their portfolio goals.
              </p>
            </div>
          </div>

          <div className="sticky top-24 space-y-4">
            <div className="relative h-[180px] rounded-2xl overflow-hidden shadow-xl">
              <img
                src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="City skyline"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="relative h-[180px] rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.pexels.com/photos/1370704/pexels-photo-1370704.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Modern architecture"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="relative h-[180px] rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.pexels.com/photos/2343468/pexels-photo-2343468.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Luxury property"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="relative h-[280px] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Luxury interior design"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Premium Service</h3>
                  <p className="text-white/90 text-sm">Delivering exceptional results across all property sectors</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            About <span className="text-[#8b7355]">Gold Collar Partners</span>
          </h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Australia's premier real estate solution provider, dedicated to transforming property investment dreams into reality.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] rounded-3xl p-8 text-white shadow-2xl">
            <div className="text-xs uppercase tracking-widest opacity-90 mb-6 font-semibold">
              Our Credibility & Experience
            </div>
            <div className="space-y-6">
              <div>
                <div className="text-6xl font-bold mb-2">250+</div>
                <div className="text-lg font-medium opacity-95">Properties Delivered</div>
                <p className="text-sm opacity-80 mt-2">Across premium Australian locations</p>
              </div>
              <div className="border-t border-white/20 pt-6">
                <div className="text-5xl font-bold mb-2">$800M+</div>
                <div className="text-lg font-medium opacity-95">Total Investments</div>
                <p className="text-sm opacity-80 mt-2">Managed successfully</p>
              </div>
              <div className="border-t border-white/20 pt-6">
                <div className="text-5xl font-bold mb-2">15+</div>
                <div className="text-lg font-medium opacity-95">Years of Experience</div>
                <p className="text-sm opacity-80 mt-2">In premium real estate</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 bg-white rounded-3xl p-8 shadow-xl border border-gray-100">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
                  <p className="text-gray-700 leading-relaxed">
                    At Gold Collar Partners, we understand the challenges of creating exceptional property portfolios. We've designed our services around what investors truly need - transparency, expertise, and results.
                  </p>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Approach</h2>
                  <p className="text-gray-700 leading-relaxed">
                    We combine deep market insights with personalized service, providing transparent guidance from initial consultation to final acquisition and beyond.
                  </p>
                </div>
              </div>
              <div className="space-y-6">
                <div className="relative h-64 rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800"
                    alt="Professional team meeting"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="bg-[#f5f1ed] rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Why Choose Us?</h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>Exclusive access to off-market properties</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>End-to-end investment support</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>Proven track record of success</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-[#8b7355] mr-2 font-bold">✓</span>
                      <span>Personalized investment strategies</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="case-studies" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Success <span className="text-[#8b7355]">Stories</span>
          </h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Explore how we've helped investors achieve exceptional returns through strategic property acquisitions and developments.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition group">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={`https://images.pexels.com/photos/${i === 1 ? '323780' : i === 2 ? '1643383' : '1370704'}/pexels-photo-${i === 1 ? '323780' : i === 2 ? '1643383' : '1370704'}.jpeg?auto=compress&cs=tinysrgb&w=600`}
                  alt={`Project ${i}`}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {i === 1 ? 'Melbourne CBD Development' : i === 2 ? 'Sydney Harbour Apartments' : 'Brisbane Luxury Residences'}
                </h3>
                <p className="text-gray-700 text-sm mb-4">
                  {i === 1 ? '28% ROI achieved through strategic positioning' : i === 2 ? 'Exclusive waterfront investment portfolio' : 'Premium development in prime location'}
                </p>
                <span className="text-[#8b7355] font-semibold text-sm">View Story →</span>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/case-studies"
            className="inline-flex items-center bg-[#8b7355] text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#6d5a42] transition group"
          >
            View More Success Stories
            <svg className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </section>

      <section id="faqs" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Frequently Asked <span className="text-[#8b7355]">Questions</span>
          </h2>
        </div>

        <div className="space-y-4">
          {[
            {
              q: 'What areas do you service?',
              a: 'We operate across all major Australian capital cities, with a particular focus on Sydney, Melbourne, and Brisbane premium markets.'
            },
            {
              q: 'How do you source off-market properties?',
              a: 'Our extensive network of developers, agents, and industry contacts gives us access to exclusive opportunities before they reach the public market.'
            },
            {
              q: 'What is the Luxury Club membership?',
              a: 'Our exclusive membership tier providing priority access to premium properties, private market insights, and personalized investment strategies.'
            },
            {
              q: 'Do you provide property management services?',
              a: 'Yes, we offer comprehensive property management solutions including tenant sourcing, maintenance coordination, and financial reporting.'
            }
          ].map((faq, idx) => (
            <div key={idx} className="bg-white rounded-xl p-6 shadow-md">
              <h3 className="text-lg font-bold text-gray-900 mb-2">{faq.q}</h3>
              <p className="text-gray-700">{faq.a}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-8">
          <Link
            to="/faqs"
            className="inline-flex items-center bg-[#8b7355] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#6d5a42] transition"
          >
            View More FAQs
            <svg className="ml-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </section>

      <section id="resources" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Free <span className="text-[#8b7355]">Resources</span> for Investors
          </h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Access our exclusive collection of investment tools and guides designed to help you make informed property decisions.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition group border border-gray-100">
            <div className="relative h-48 overflow-hidden">
              <img
                src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Investment toolkit and documents"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#8b7355]/80 to-transparent flex items-end">
                <div className="p-6">
                  <BookOpen className="h-10 w-10 text-white" />
                </div>
              </div>
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
                Property Investment Toolkit
              </h3>
              <p className="text-gray-700 leading-relaxed mb-6">
                Comprehensive guide covering market analysis, due diligence checklists, and investment strategies to help you navigate the property market with confidence.
              </p>
              <button onClick={() => openNewsletterForm('https://example.com/investment-toolkit.pdf')} className="bg-[#8b7355] text-white px-6 py-2.5 rounded-lg font-medium hover:bg-[#6d5a42] transition w-full">
                Download Free
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition group border border-gray-100">
            <div className="relative h-48 overflow-hidden">
              <img
                src="https://images.pexels.com/photos/3184298/pexels-photo-3184298.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Portfolio planning and strategy"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#8b7355]/80 to-transparent flex items-end">
                <div className="p-6">
                  <FileText className="h-10 w-10 text-white" />
                </div>
              </div>
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
                Portfolio Building Guide
              </h3>
              <p className="text-gray-700 leading-relaxed mb-6">
                Learn how to build a diversified property portfolio that generates consistent returns. Includes case studies and proven strategies from successful investors.
              </p>
              <button onClick={() => openNewsletterForm('https://example.com/investment-toolkit.pdf')} className="bg-[#8b7355] text-white px-6 py-2.5 rounded-lg font-medium hover:bg-[#6d5a42] transition w-full">
                Download Free
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition group border border-gray-100">
            <div className="relative h-48 overflow-hidden">
              <img
                src="https://images.pexels.com/photos/3184325/pexels-photo-3184325.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Financial calculator and analysis"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#8b7355]/80 to-transparent flex items-end">
                <div className="p-6">
                  <Calculator className="h-10 w-10 text-white" />
                </div>
              </div>
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
                Yield Calculator
              </h3>
              <p className="text-gray-700 leading-relaxed mb-6">
                Calculate potential returns on your property investments with our easy-to-use tool. Includes rental yield, capital growth projections, and ROI analysis.
              </p>
              <button className="bg-[#8b7355] text-white px-6 py-2.5 rounded-lg font-medium hover:bg-[#6d5a42] transition w-full">
                Access Calculator
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
