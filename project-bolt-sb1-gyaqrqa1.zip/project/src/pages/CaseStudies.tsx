import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Bed, Home, DollarSign, MapPin, TrendingUp, X } from 'lucide-react';
import { useFormContext } from '../context/FormContext';

export function CaseStudies() {
  const { openContactForm } = useFormContext();
  const [selectedCase, setSelectedCase] = useState<number | null>(null);
  const successStories = [
    {
      id: 1,
      image: "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=800",
      title: "Melbourne CBD Development",
      roi: "28%",
      description: "Strategic positioning in Melbourne's fastest-growing corridor delivered exceptional returns for our investor clients within 18 months.",
      metrics: {
        investment: "$2.5M",
        currentValue: "$3.2M",
        yield: "6.8%"
      }
    },
    {
      id: 2,
      image: "https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800",
      title: "Sydney Harbour Apartments",
      roi: "22%",
      description: "Exclusive waterfront investment portfolio secured off-market, providing clients with prime harbor views and strong capital growth.",
      metrics: {
        investment: "$4.8M",
        currentValue: "$5.9M",
        yield: "4.2%"
      }
    },
    {
      id: 3,
      image: "https://images.pexels.com/photos/1370704/pexels-photo-1370704.jpeg?auto=compress&cs=tinysrgb&w=800",
      title: "Brisbane Luxury Residences",
      roi: "31%",
      description: "Premium development in prime location capitalized on Brisbane's property boom, delivering outstanding returns ahead of schedule.",
      metrics: {
        investment: "$1.9M",
        currentValue: "$2.5M",
        yield: "7.1%"
      }
    },
    {
      id: 4,
      image: "https://images.pexels.com/photos/2121121/pexels-photo-2121121.jpeg?auto=compress&cs=tinysrgb&w=800",
      title: "Gold Coast Beachfront Villa",
      roi: "26%",
      description: "Luxury beachfront property secured through our exclusive network, now generating premium rental income and steady appreciation.",
      metrics: {
        investment: "$3.2M",
        currentValue: "$4.0M",
        yield: "5.5%"
      }
    },
    {
      id: 5,
      image: "https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg?auto=compress&cs=tinysrgb&w=800",
      title: "Perth Riverside Development",
      roi: "34%",
      description: "Off-market opportunity in Perth's riverside precinct delivered exceptional growth as the area underwent major infrastructure upgrades.",
      metrics: {
        investment: "$1.4M",
        currentValue: "$1.9M",
        yield: "6.9%"
      }
    },
    {
      id: 6,
      image: "https://images.pexels.com/photos/2462015/pexels-photo-2462015.jpeg?auto=compress&cs=tinysrgb&w=800",
      title: "Adelaide Hills Estate",
      roi: "19%",
      description: "Boutique vineyard estate acquisition providing both lifestyle benefits and strong investment returns in South Australia's premium wine region.",
      metrics: {
        investment: "$2.1M",
        currentValue: "$2.5M",
        yield: "4.8%"
      }
    }
  ];

  const caseStudies = [
    {
      id: 1,
      image: "https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=1200",
      customerName: "Sarah & Michael Thompson",
      address: "15 Canterbury Road, Toorak, VIC 3142",
      bedrooms: 5,
      landSize: "850 sqm",
      soldPrice: "$4,750,000",
      propertyType: "Luxury Family Home",
      details: "This stunning five-bedroom Victorian-era mansion in the prestigious Toorak neighborhood presented unique challenges. The property required extensive heritage compliance work while maintaining its historical integrity. Our team navigated complex council regulations, coordinated with heritage architects, and negotiated a competitive price despite multiple interested parties. The property featured period details including ornate cornices, marble fireplaces, and stained glass windows that needed preservation. After a thorough 8-week campaign, we secured this exceptional property $250,000 under the initial asking price, saving our clients substantial capital while delivering their dream family home."
    },
    {
      id: 2,
      image: "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1200",
      customerName: "James Chen",
      address: "2407/120 Collins Street, Melbourne CBD, VIC 3000",
      bedrooms: 1,
      landSize: "65 sqm",
      soldPrice: "$685,000",
      propertyType: "Premium Apartment",
      details: "Located in Melbourne's iconic skyline, this one-bedroom apartment presented unique investment challenges. The building had upcoming major works affecting body corporate fees, and the seller was motivated but non-transparent about building issues. Our due diligence uncovered planned façade repairs that would have cost $45,000 in levies. We negotiated this amount off the purchase price and secured building management reports that revealed the true condition. The property offers spectacular city views and premium amenities including pool, gym, and concierge. Despite the complex strata negotiations and building report complications, we delivered an investment property with strong rental yields and future capital growth potential."
    },
    {
      id: 3,
      image: "https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=1200",
      customerName: "Emma & David Foster",
      address: "42 Beaconsfield Parade, Albert Park, VIC 3206",
      bedrooms: 3,
      landSize: "320 sqm",
      soldPrice: "$2,450,000",
      propertyType: "Beachside Terrace",
      details: "This charming three-bedroom terrace home near Albert Park Beach came with significant structural challenges. Initial inspections revealed foundation issues, rising damp, and outdated electrical systems that would require $180,000 in immediate remediation. The property was caught in a heated bidding war with seven other parties, making negotiation extremely difficult. Our team brought in structural engineers pre-auction, quantified all repair costs, and developed a comprehensive renovation strategy. We advised our clients on maximum bid limits and helped them understand the true value post-renovation. Through strategic bidding and leveraging our building cost estimates, we secured the property and negotiated a $120,000 vendor contribution toward repairs, transforming potential disaster into an incredible beachside opportunity."
    }
  ];

  return (
    <main className="pt-20">
      <section className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] text-white py-20 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/3184433/pexels-photo-3184433.jpeg?auto=compress&cs=tinysrgb&w=1200)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h1 className="text-5xl font-bold mb-6">Success Stories & Case Studies</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Real stories from real clients. Discover how we've helped property buyers and investors achieve exceptional results across Australia.
          </p>
        </div>
      </section>

      <section className="bg-[#f5f1ed] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Detailed <span className="text-[#8b7355]">Case Studies</span>
            </h2>
            <p className="text-gray-700 max-w-2xl mx-auto">
              Dive deep into the challenges, strategies, and outcomes of our most complex property acquisitions.
            </p>
          </div>

          <div className="space-y-16">
            {caseStudies.map((study, index) => (
              <div key={study.id} className={`grid lg:grid-cols-2 gap-8 items-center ${index % 2 === 1 ? 'lg:grid-flow-dense' : ''}`}>
                <div className={`${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                  <div className="relative h-[400px] rounded-2xl overflow-hidden shadow-2xl">
                    <img
                      src={study.image}
                      alt={study.address}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-lg">
                      <p className="text-[#8b7355] font-bold text-lg">{study.soldPrice}</p>
                    </div>
                  </div>
                </div>

                <div className={`${index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}`}>
                  <div className="bg-white rounded-2xl p-8 shadow-lg h-[400px] flex flex-col">
                    <div className="inline-block bg-[#8b7355]/10 text-[#8b7355] px-4 py-1 rounded-full text-sm font-semibold mb-4 w-fit">
                      {study.propertyType}
                    </div>

                    <h2 className="text-2xl font-bold text-gray-900 mb-2">
                      {study.customerName}
                    </h2>

                    <div className="flex items-start text-gray-600 mb-4 text-sm">
                      <MapPin className="h-4 w-4 mr-2 flex-shrink-0 mt-0.5" />
                      <span>{study.address}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-3 mb-4 pb-4 border-b border-gray-200">
                      <div className="flex items-center space-x-2">
                        <Bed className="h-4 w-4 text-[#8b7355]" />
                        <div>
                          <p className="text-xs text-gray-500">Bedrooms</p>
                          <p className="font-bold text-gray-900 text-sm">{study.bedrooms}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Home className="h-4 w-4 text-[#8b7355]" />
                        <div>
                          <p className="text-xs text-gray-500">Land Size</p>
                          <p className="font-bold text-gray-900 text-sm">{study.landSize}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <DollarSign className="h-4 w-4 text-[#8b7355]" />
                        <div>
                          <p className="text-xs text-gray-500">Sale Price</p>
                          <p className="font-bold text-gray-900 text-sm">{study.soldPrice}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mb-4 flex-grow overflow-hidden">
                      <h3 className="text-base font-bold text-gray-900 mb-2">The Challenge</h3>
                      <p className="text-gray-700 leading-relaxed text-sm line-clamp-4">
                        {study.details}
                      </p>
                    </div>

                    <div className="flex gap-3 mt-auto">
                      <button
                        onClick={() => setSelectedCase(study.id)}
                        className="inline-flex items-center text-[#8b7355] font-semibold text-sm hover:text-[#6d5a42] transition"
                      >
                        Read More
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </button>
                      <button
                        onClick={openContactForm}
                        className="inline-flex items-center bg-[#8b7355] text-white px-5 py-2 rounded-lg font-semibold text-sm hover:bg-[#6d5a42] transition group ml-auto"
                      >
                        Contact Us
                        <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Success <span className="text-[#8b7355]">Stories</span>
          </h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Our portfolio speaks for itself. These success stories showcase the exceptional returns and strategic acquisitions we've delivered for our clients.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {successStories.map((story) => (
            <div key={story.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition group">
              <div className="relative h-56 overflow-hidden">
                <img
                  src={story.image}
                  alt={story.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-[#8b7355] text-white px-4 py-2 rounded-lg flex items-center space-x-1">
                  <TrendingUp className="h-4 w-4" />
                  <span className="font-bold">{story.roi} ROI</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{story.title}</h3>
                <p className="text-gray-700 text-sm mb-4 leading-relaxed">{story.description}</p>

                <div className="grid grid-cols-3 gap-3 pt-4 border-t border-gray-200">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Investment</p>
                    <p className="font-bold text-gray-900 text-sm">{story.metrics.investment}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Value</p>
                    <p className="font-bold text-gray-900 text-sm">{story.metrics.currentValue}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Yield</p>
                    <p className="font-bold text-gray-900 text-sm">{story.metrics.yield}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button
            onClick={openContactForm}
            className="inline-flex items-center bg-[#8b7355] text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#6d5a42] transition group"
          >
            Start Your Success Story
            <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      <section className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] text-white py-16 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1200)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl font-bold mb-4">Ready to Write Your Success Story?</h2>
          <p className="text-xl text-white/90 mb-8">
            Let our experienced team guide you through your property journey. From complex negotiations to seamless settlements, we're here to help you achieve exceptional results.
          </p>
          <button
            onClick={openContactForm}
            className="inline-flex items-center bg-white text-[#8b7355] px-8 py-4 rounded-lg font-bold hover:bg-[#f5f1ed] transition text-lg group"
          >
            Book Your Free Consultation
            <ArrowRight className="ml-2 h-6 w-6 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      {selectedCase && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedCase(null)}>
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl" onClick={(e) => e.stopPropagation()}>
            {caseStudies.map((study) => {
              if (study.id !== selectedCase) return null;
              return (
                <div key={study.id}>
                  <div className="relative h-[300px] rounded-t-3xl overflow-hidden">
                    <img
                      src={study.image}
                      alt={study.address}
                      className="w-full h-full object-cover"
                    />
                    <button
                      onClick={() => setSelectedCase(null)}
                      className="absolute top-4 right-4 bg-white rounded-full p-2 hover:bg-gray-100 transition shadow-lg"
                    >
                      <X className="h-6 w-6 text-gray-900" />
                    </button>
                    <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-lg">
                      <p className="text-[#8b7355] font-bold text-lg">{study.soldPrice}</p>
                    </div>
                  </div>

                  <div className="p-8 lg:p-12">
                    <div className="inline-block bg-[#8b7355]/10 text-[#8b7355] px-4 py-1 rounded-full text-sm font-semibold mb-4">
                      {study.propertyType}
                    </div>

                    <h2 className="text-4xl font-bold text-gray-900 mb-3">
                      {study.customerName}
                    </h2>

                    <div className="flex items-start text-gray-600 mb-6">
                      <MapPin className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-lg">{study.address}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-6 mb-8 pb-8 border-b border-gray-200">
                      <div className="flex items-center space-x-3">
                        <Bed className="h-6 w-6 text-[#8b7355]" />
                        <div>
                          <p className="text-sm text-gray-500">Bedrooms</p>
                          <p className="font-bold text-gray-900 text-lg">{study.bedrooms}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Home className="h-6 w-6 text-[#8b7355]" />
                        <div>
                          <p className="text-sm text-gray-500">Land Size</p>
                          <p className="font-bold text-gray-900 text-lg">{study.landSize}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <DollarSign className="h-6 w-6 text-[#8b7355]" />
                        <div>
                          <p className="text-sm text-gray-500">Sale Price</p>
                          <p className="font-bold text-gray-900 text-lg">{study.soldPrice}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mb-8">
                      <h3 className="text-2xl font-bold text-gray-900 mb-4">The Challenge</h3>
                      <p className="text-gray-700 leading-relaxed text-lg">
                        {study.details}
                      </p>
                    </div>

                    <div className="flex gap-4">
                      <Link
                        to="/contact"
                        className="inline-flex items-center bg-[#8b7355] text-white px-8 py-4 rounded-lg font-bold hover:bg-[#6d5a42] transition group"
                      >
                        Discuss Your Property Goals
                        <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                      </Link>
                      <button
                        onClick={() => setSelectedCase(null)}
                        className="inline-flex items-center bg-gray-100 text-gray-900 px-8 py-4 rounded-lg font-bold hover:bg-gray-200 transition"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </main>
  );
}
