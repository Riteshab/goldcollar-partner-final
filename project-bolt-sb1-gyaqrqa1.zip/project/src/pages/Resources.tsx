import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, FileText, BookOpen, TrendingUp, Calendar, ArrowRight, Mail } from 'lucide-react';
import { useFormContext } from '../context/FormContext';

export function Resources() {
  const { openNewsletterForm } = useFormContext();
  const [newsletterData, setNewsletterData] = useState({ name: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const resources = [
    {
      id: 1,
      title: "Property Investment Guide 2024",
      description: "Comprehensive guide covering market trends, investment strategies, and expert insights for Australian property investors.",
      type: "PDF Guide",
      icon: FileText,
      downloadUrl: "#",
      category: "Investment"
    },
    {
      id: 2,
      title: "Buyer's Checklist",
      description: "Essential checklist for property buyers covering due diligence, inspections, and legal requirements.",
      type: "Checklist",
      icon: FileText,
      downloadUrl: "#",
      category: "Buying"
    },
    {
      id: 3,
      title: "Market Analysis Report",
      description: "Quarterly market analysis covering major Australian cities with price trends and growth forecasts.",
      type: "Report",
      icon: TrendingUp,
      downloadUrl: "#",
      category: "Market Data"
    },
    {
      id: 4,
      title: "First Home Buyer Guide",
      description: "Step-by-step guide for first-time buyers including government grants, financing options, and tips.",
      type: "PDF Guide",
      icon: BookOpen,
      downloadUrl: "#",
      category: "First Home"
    },
    {
      id: 5,
      title: "Investment Property Calculator",
      description: "Excel template to calculate ROI, rental yields, and cash flow for your investment properties.",
      type: "Excel Tool",
      icon: FileText,
      downloadUrl: "#",
      category: "Tools"
    },
    {
      id: 6,
      title: "Property Due Diligence Guide",
      description: "Detailed guide on conducting thorough property inspections and assessments before purchase.",
      type: "PDF Guide",
      icon: FileText,
      downloadUrl: "#",
      category: "Due Diligence"
    }
  ];

  const blogPosts = [
    {
      id: 1,
      title: "5 Key Trends Shaping Australian Property Market in 2024",
      excerpt: "Discover the major trends influencing property prices and investment opportunities across Australia this year.",
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "March 15, 2024",
      category: "Market Insights",
      readTime: "5 min read"
    },
    {
      id: 2,
      title: "How to Maximize ROI on Your Investment Property",
      excerpt: "Expert strategies to increase rental yields and capital growth on your property investments.",
      image: "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "March 10, 2024",
      category: "Investment Tips",
      readTime: "7 min read"
    },
    {
      id: 3,
      title: "Understanding Off-Market Properties: A Buyer's Advantage",
      excerpt: "Learn why off-market properties offer unique opportunities and how to access them.",
      image: "https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "March 5, 2024",
      category: "Buying Tips",
      readTime: "6 min read"
    },
    {
      id: 4,
      title: "The Rise of Sustainable Property Development",
      excerpt: "Exploring how eco-friendly developments are reshaping the Australian property landscape.",
      image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "February 28, 2024",
      category: "Development",
      readTime: "8 min read"
    },
    {
      id: 5,
      title: "Melbourne vs Sydney: Where Should You Invest?",
      excerpt: "Comparative analysis of investment opportunities in Australia's two largest property markets.",
      image: "https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "February 20, 2024",
      category: "Market Comparison",
      readTime: "10 min read"
    },
    {
      id: 6,
      title: "Navigating Property Finance: A Complete Guide",
      excerpt: "Everything you need to know about securing finance for your property purchase.",
      image: "https://images.pexels.com/photos/3184433/pexels-photo-3184433.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "February 15, 2024",
      category: "Finance",
      readTime: "9 min read"
    }
  ];

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage('');

    setTimeout(() => {
      setSubmitMessage('Thank you for subscribing! We will integrate the database in later stages.');
      setNewsletterData({ name: '', email: '' });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <main className="pt-20">
      <section className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] text-white py-20 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=1200)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h1 className="text-5xl font-bold mb-6">Resources & Insights</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Access our comprehensive library of property investment guides, market reports, and expert insights to help you make informed decisions.
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Downloadable <span className="text-[#8b7355]">Resources</span>
          </h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            Free guides, checklists, and tools to support your property investment journey.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource) => {
            const Icon = resource.icon;
            return (
              <div key={resource.id} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition group">
                <div className="flex items-start justify-between mb-4">
                  <div className="bg-[#8b7355]/10 p-3 rounded-lg">
                    <Icon className="h-6 w-6 text-[#8b7355]" />
                  </div>
                  <span className="text-xs bg-[#f5f1ed] text-[#8b7355] px-3 py-1 rounded-full font-semibold">
                    {resource.category}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-2">{resource.title}</h3>
                <p className="text-gray-700 text-sm mb-4 leading-relaxed">{resource.description}</p>

                <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                  <span className="text-xs text-gray-500 font-medium">{resource.type}</span>
                  <button
                    onClick={() => openNewsletterForm(resource.downloadUrl)}
                    className="inline-flex items-center text-[#8b7355] font-semibold text-sm hover:text-[#6d5a42] transition group"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Download
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="bg-[#f5f1ed] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Latest <span className="text-[#8b7355]">Blog & News</span>
            </h2>
            <p className="text-gray-700 max-w-2xl mx-auto">
              Stay informed with our latest articles, market updates, and expert insights on property investment.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition group">
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4 bg-[#8b7355] text-white px-3 py-1 rounded-lg text-xs font-semibold">
                    {post.category}
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center text-xs text-gray-500 mb-3 space-x-4">
                    <span className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {post.date}
                    </span>
                    <span>{post.readTime}</span>
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">{post.title}</h3>
                  <p className="text-gray-700 text-sm mb-4 leading-relaxed line-clamp-3">{post.excerpt}</p>

                  <a
                    href="#"
                    className="inline-flex items-center text-[#8b7355] font-semibold text-sm hover:text-[#6d5a42] transition group"
                  >
                    Read More
                    <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </article>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              to="/contact"
              className="inline-flex items-center bg-[#8b7355] text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#6d5a42] transition group"
            >
              View All Articles
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] rounded-3xl p-12 text-white relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: 'url(https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1200)',
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />

          <div className="relative z-10 text-center">
            <div className="inline-flex items-center justify-center bg-white/20 rounded-full p-4 mb-6">
              <Mail className="h-8 w-8" />
            </div>

            <h2 className="text-3xl font-bold mb-4">Subscribe to Our Newsletter</h2>
            <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
              Get exclusive property insights, market updates, and investment tips delivered straight to your inbox every week.
            </p>

            <form onSubmit={handleNewsletterSubmit} className="max-w-xl mx-auto">
              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  value={newsletterData.name}
                  onChange={(e) => setNewsletterData({ ...newsletterData, name: e.target.value })}
                  className="w-full px-6 py-3 rounded-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white/50"
                  required
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  value={newsletterData.email}
                  onChange={(e) => setNewsletterData({ ...newsletterData, email: e.target.value })}
                  className="w-full px-6 py-3 rounded-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white/50"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-white text-[#8b7355] px-8 py-4 rounded-lg font-bold hover:bg-[#f5f1ed] transition disabled:opacity-50"
              >
                {isSubmitting ? 'Subscribing...' : 'Subscribe Now'}
              </button>

              {submitMessage && (
                <p className="mt-4 text-white/90 text-sm">{submitMessage}</p>
              )}
            </form>

            <p className="text-xs text-white/70 mt-6">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-white rounded-3xl p-12 shadow-xl text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Need Personalized Advice?</h2>
          <p className="text-lg text-gray-700 mb-8 max-w-2xl mx-auto">
            Our team of property experts is ready to help you navigate your investment journey with tailored strategies and insights.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center bg-[#8b7355] text-white px-8 py-4 rounded-lg font-bold hover:bg-[#6d5a42] transition text-lg group"
          >
            Schedule a Consultation
            <ArrowRight className="ml-2 h-6 w-6 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </main>
  );
}
