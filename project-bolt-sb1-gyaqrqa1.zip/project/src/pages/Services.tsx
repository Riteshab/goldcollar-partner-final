import { Link } from 'react-router-dom';
import { ArrowRight, TrendingUp, Briefcase, BarChart3, Users, Home, PiggyBank, Building2, Crown, Phone, Mail, MessageCircle, CheckCircle } from 'lucide-react';
import { useFormContext } from '../context/FormContext';

export function Services() {
  const { openContactForm } = useFormContext();
  const services = [
    {
      id: 1,
      icon: TrendingUp,
      title: "Real Estate Advisory",
      description: "Expert guidance on property investments, market trends, and portfolio optimization strategies.",
      image: "https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: [
        "Comprehensive market analysis and trend forecasting",
        "Investment strategy development and portfolio review",
        "Risk assessment and mitigation planning",
        "Property valuation and comparative market analysis",
        "Long-term wealth building strategies through real estate",
        "Ongoing advisory support and market updates"
      ],
      color: "from-orange-500 to-orange-600"
    },
    {
      id: 2,
      icon: Briefcase,
      title: "Portfolio Management",
      description: "Comprehensive management of your real estate assets to maximize returns and minimize risks.",
      image: "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: [
        "Active portfolio monitoring and performance tracking",
        "Strategic asset allocation and diversification",
        "Rental yield optimization and cash flow management",
        "Property maintenance coordination and oversight",
        "Tenant management and lease administration",
        "Regular portfolio reporting and performance reviews"
      ],
      color: "from-orange-500 to-orange-600"
    },
    {
      id: 3,
      icon: BarChart3,
      title: "Market Research & Analytics",
      description: "Data-driven insights and detailed market analysis to inform your investment decisions.",
      image: "https://images.pexels.com/photos/3184433/pexels-photo-3184433.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: [
        "Detailed suburb and regional market analysis",
        "Growth corridor identification and forecasting",
        "Infrastructure development impact assessments",
        "Supply and demand dynamics evaluation",
        "Capital growth and rental yield projections",
        "Competitive market positioning analysis"
      ],
      color: "from-orange-500 to-orange-600"
    },
    {
      id: 4,
      icon: Users,
      title: "Joint Venture Planning",
      description: "Strategic partnerships and collaborative investment opportunities for larger projects.",
      image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: [
        "Joint venture structuring and partnership agreements",
        "Investment syndication for premium opportunities",
        "Due diligence and partner vetting processes",
        "Profit sharing and equity distribution planning",
        "Project governance and decision-making frameworks",
        "Exit strategy planning and implementation"
      ],
      color: "from-orange-500 to-orange-600"
    },
    {
      id: 5,
      icon: Home,
      title: "Property Acquisition Strategy",
      description: "Tailored acquisition plans that align with your investment goals and financial capacity.",
      image: "https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: [
        "Customized property search and selection criteria",
        "Off-market opportunity identification and access",
        "Negotiation strategy and execution",
        "Pre-purchase due diligence and inspections",
        "Financial structuring and lending solutions",
        "Settlement coordination and handover support"
      ],
      color: "from-orange-500 to-orange-600"
    },
    {
      id: 6,
      icon: PiggyBank,
      title: "Wealth & Tax Planning",
      description: "Integrated financial planning to optimize your wealth and tax efficiency through real estate.",
      image: "https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: [
        "Tax-effective property ownership structures",
        "Depreciation scheduling and tax benefit maximization",
        "Capital gains tax planning and strategies",
        "Estate planning through property assets",
        "Self-managed super fund (SMSF) property investments",
        "Wealth preservation and succession planning"
      ],
      color: "from-orange-500 to-orange-600"
    }
  ];

  const divisions = [
    {
      icon: Home,
      title: "Buyers Agent",
      description: "Expert property acquisition, negotiation, and settlement services for residential and investment properties.",
      link: "/services#buyers-agent"
    },
    {
      icon: Building2,
      title: "Property Developer",
      description: "End-to-end development solutions from site acquisition to project delivery and sales.",
      link: "/services#property-developer"
    },
    {
      icon: Crown,
      title: "Luxury Club",
      description: "Exclusive membership providing priority access to premium off-market opportunities and investment insights.",
      link: "/services#luxury-club"
    }
  ];

  return (
    <main className="pt-20">
      <section className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] text-white py-20 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1200)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h1 className="text-5xl font-bold mb-6">Comprehensive Property Services</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
            From strategic advisory to hands-on management, we provide end-to-end solutions designed to maximize your investment returns and build lasting wealth through real estate.
          </p>
          <div className="flex justify-center">
            <button
              onClick={openContactForm}
              className="inline-flex items-center bg-white text-[#8b7355] px-8 py-4 rounded-lg font-bold hover:bg-[#f5f1ed] transition text-lg group"
            >
              Start Your Property Journey
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our <span className="text-[#8b7355]">Main Divisions</span>
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Three specialized divisions delivering comprehensive property solutions across all market segments.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {divisions.map((division, idx) => {
            const Icon = division.icon;
            return (
              <div key={idx} className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] rounded-2xl p-8 text-white shadow-xl hover:shadow-2xl transition group relative overflow-hidden">
                <div
                  className="absolute inset-0 opacity-10"
                  style={{
                    backgroundImage: 'url(https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                />
                <div className="relative z-10">
                  <div className="bg-white/20 backdrop-blur-sm rounded-full w-16 h-16 flex items-center justify-center mb-6">
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{division.title}</h3>
                  <p className="text-white/90 leading-relaxed mb-6">{division.description}</p>
                  <div className="inline-flex items-center text-white font-semibold hover:text-[#d4a855] transition cursor-pointer">
                    Explore Division
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our <span className="text-[#8b7355]">Services</span>
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Six specialized services working together to deliver exceptional results across every aspect of your property investment journey.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div key={service.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition group">
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-gray-900/40 to-transparent" />
                  <div className={`absolute top-4 left-4 bg-gradient-to-r ${service.color} rounded-lg p-3 shadow-lg`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-700 leading-relaxed mb-6">{service.description}</p>

                  <div className="bg-[#f5f1ed] rounded-xl p-4 mb-6">
                    <h4 className="text-sm font-bold text-gray-900 mb-3 flex items-center">
                      <CheckCircle className="h-4 w-4 text-[#8b7355] mr-2" />
                      Key Features
                    </h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start text-sm text-gray-700">
                          <span className="text-[#8b7355] mr-2 font-bold">•</span>
                          <span className="leading-relaxed">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    onClick={openContactForm}
                    className="inline-flex items-center text-[#8b7355] font-semibold hover:text-[#6d5a42] transition group"
                  >
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-br from-[#8b7355] to-[#6d5a42] rounded-3xl p-12 text-white text-center relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: 'url(https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1200)',
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />
          <div className="relative z-10">
            <h2 className="text-3xl font-bold mb-4">Need a Customized Solution?</h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Every property journey is unique. Let us create a tailored service package that perfectly aligns with your investment goals and financial objectives.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center bg-white text-[#8b7355] px-8 py-4 rounded-lg font-bold hover:bg-[#f5f1ed] transition text-lg group"
            >
              Schedule a Consultation
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      <section className="bg-[#f5f1ed] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose <span className="text-[#8b7355]">Gold Collar Partners</span>
            </h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              We combine decades of experience, proven results, and unwavering dedication to deliver exceptional outcomes for every client.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="text-5xl font-bold text-[#8b7355] mb-4">98%</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Success Rate</h3>
              <p className="text-gray-700 leading-relaxed">
                We secure the right property for 98% of our clients, often exceeding their expectations.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="text-5xl font-bold text-[#8b7355] mb-4">$127K</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Average Savings</h3>
              <p className="text-gray-700 leading-relaxed">
                Our expert negotiation skills save clients an average of $127,000 per transaction.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="text-5xl font-bold text-[#8b7355] mb-4">250+</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Happy Clients</h3>
              <p className="text-gray-700 leading-relaxed">
                Join hundreds of satisfied clients who've achieved their property goals with us.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-16 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1200)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-white/90 text-lg mb-6">
                Whether you're a first-time buyer, seasoned investor, or looking to optimize your property portfolio, our expert team is ready to help you achieve your investment goals.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <Phone className="h-5 w-5 text-[#d4a855] mr-3 flex-shrink-0" />
                  <span>Speak directly with a property expert</span>
                </li>
                <li className="flex items-center">
                  <Mail className="h-5 w-5 text-[#d4a855] mr-3 flex-shrink-0" />
                  <span>Get detailed responses within 24 hours</span>
                </li>
                <li className="flex items-center">
                  <MessageCircle className="h-5 w-5 text-[#d4a855] mr-3 flex-shrink-0" />
                  <span>Book a free consultation to discuss your goals</span>
                </li>
              </ul>
              <Link
                to="/contact"
                className="inline-flex items-center bg-[#8b7355] text-white px-8 py-4 rounded-lg font-bold hover:bg-[#6d5a42] transition group"
              >
                Get in Touch
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            <div className="relative">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold mb-6">Our Services</h3>
                <div className="space-y-4">
                  {[
                    { title: 'Real Estate Advisory', desc: 'Expert guidance and strategy development', icon: TrendingUp },
                    { title: 'Portfolio Management', desc: 'Maximize returns and minimize risks', icon: Briefcase },
                    { title: 'Market Research', desc: 'Data-driven insights and analysis', icon: BarChart3 },
                    { title: 'Property Acquisition', desc: 'Tailored acquisition strategies', icon: Home },
                    { title: 'Joint Ventures', desc: 'Strategic partnership opportunities', icon: Users },
                    { title: 'Wealth Planning', desc: 'Tax-effective property investments', icon: PiggyBank }
                  ].map((topic, idx) => {
                    const TopicIcon = topic.icon;
                    return (
                      <div key={idx} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-white/5 transition cursor-pointer">
                        <div className="bg-[#8b7355] rounded-full p-2 flex-shrink-0">
                          <TopicIcon className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <h4 className="font-semibold">{topic.title}</h4>
                          <p className="text-sm text-white/70">{topic.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
